package com.myproject;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MyListActivity extends AppCompatActivity {

    ListView mydatalist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_list);

        mydatalist = findViewById(R.id.dbListView);

        DatabaseHandler db = new DatabaseHandler(this);

        /*try {
            if (db.getTextsCount() == 0) {
                db.addText("This is a text 1!");
                db.addText("This is a text 2!");
                db.addText("This is a text 3!");
                db.addText("This is a text 4!");
                db.addText("This is a text 5!");
            }
        }
        catch (Exception e){
            db.addText("This is a text 1!");
            db.addText("This is a text 2!");
            db.addText("This is a text 3!");
            db.addText("This is a text 4!");
            db.addText("This is a text 5!");
        }*/

        // Reading all contacts
        List<MyText> texts = db.getAllTexts();
        List<String> mytexts = new ArrayList<>();

        for(MyText i: texts){
            mytexts.add(i.getText());
        }

        ArrayAdapter<String> itemsAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mytexts);
        mydatalist.setAdapter(itemsAdapter);

    }
}