package com.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView viewWelcome;
    TextView viewText;
    EditText editTxtName;
    EditText editTxtText;
    Button btnName;
    Button btnTxt;
    Button btnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewWelcome = findViewById(R.id.textViewName);
        viewText = findViewById(R.id.textViewText);
        editTxtName = findViewById(R.id.editTextName);
        editTxtText = findViewById(R.id.editTextTxt);
        btnName = findViewById(R.id.buttonOkName);
        btnTxt = findViewById(R.id.buttonOkText);
        btnList = findViewById(R.id.buttonList);

        DatabaseHandler db = new DatabaseHandler(this);

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        btnName.setOnClickListener(v -> {
            editor.putString("name", editTxtName.getText().toString());
            editor.apply();

            viewWelcome.setText(getString(R.string.welcome) + " " + sharedPref.getString("name", ""));
        });

        btnTxt.setOnClickListener(v -> {
            editor.putString("text", editTxtText.getText().toString());
            editor.apply();

            viewText.setText(sharedPref.getString("text", ""));
            db.addText(editTxtText.getText().toString());
        });

        btnList.setOnClickListener(view -> {
            Intent i = new Intent(getApplicationContext(), MyListActivity.class);
            startActivity(i);
        });
    }
}